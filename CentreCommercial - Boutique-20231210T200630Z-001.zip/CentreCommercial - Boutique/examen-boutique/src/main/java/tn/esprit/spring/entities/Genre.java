package tn.esprit.spring.entities;

public enum Genre {
	MASCULIN, FEMININ
}
