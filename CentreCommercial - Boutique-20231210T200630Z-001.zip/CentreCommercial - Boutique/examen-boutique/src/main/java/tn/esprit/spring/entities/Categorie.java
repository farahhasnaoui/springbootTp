package tn.esprit.spring.entities;

public enum Categorie {
	Sport, Enfant, Adulte
}
