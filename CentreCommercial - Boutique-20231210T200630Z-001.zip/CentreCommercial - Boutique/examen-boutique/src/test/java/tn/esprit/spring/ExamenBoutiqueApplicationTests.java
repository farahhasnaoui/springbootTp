package tn.esprit.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenBoutiqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
